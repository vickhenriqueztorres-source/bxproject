import { Redis } from "ioredis";
import fs from "node:fs";
import path from "node:path";

export interface ReserveRiskParams {
  symbol: string;
  direction: "UP" | "DOWN";
  expiryBucket: Date;
  stakeMinor: number;
  payoutPercentage?: number;
}

export class RiskManager {
  private redis: Redis;
  private checkScript: string;
  private releaseScript: string;

  readonly DEFAULT_FLOAT_MINOR = 100_000_000; // US$ 1.000.000,00 inicial (100 traders demo)
  readonly PAYOUT_PERCENTAGE = 85;

  constructor(redis: Redis) {
    this.redis = redis;

    this.checkScript = `
      local deposit_float = tonumber(redis.call('GET', KEYS[1]) or '0')
      if deposit_float <= 0 then
        return {-1, 'ERR_NO_DEPOSIT_FLOAT'}
      end

      local max_risk_cap = math.floor(deposit_float * 0.03)
      local stake_minor = tonumber(ARGV[1])
      local payout_pct = tonumber(ARGV[2])
      local additional_risk = math.floor(stake_minor * payout_pct / 100)

      local current_exposure = tonumber(redis.call('GET', KEYS[2]) or '0')
      if (current_exposure + additional_risk) > max_risk_cap then
        return {-2, 'ERR_RISK_CAP_EXCEEDED'}
      end

      local new_exposure = redis.call('INCRBY', KEYS[2], additional_risk)
      redis.call('EXPIRE', KEYS[2], tonumber(ARGV[3]))

      return {1, 'APPROVED', new_exposure}
    `;

    this.releaseScript = `
      local current_exposure = tonumber(redis.call('GET', KEYS[1]) or '0')
      local amount_to_release = tonumber(ARGV[1])

      if current_exposure > 0 and amount_to_release > 0 then
        local to_decr = math.min(current_exposure, amount_to_release)
        redis.call('DECRBY', KEYS[1], to_decr)
      end

      return 1
    `;
  }

  async ensureDepositFloat(): Promise<void> {
    const floatKey = "broker:deposit_float_minor";
    const exists = await this.redis.exists(floatKey);
    if (!exists) {
      await this.redis.set(floatKey, this.DEFAULT_FLOAT_MINOR.toString());
    }
  }

  getRiskKey(symbol: string, expiryBucket: Date, direction: string): string {
    const bucketStartMs = Math.floor(expiryBucket.getTime() / 60000) * 60000;
    return `risk:candle:${symbol}:${bucketStartMs}:${direction}`;
  }

  async checkAndReserveRisk(params: ReserveRiskParams): Promise<{ approved: boolean; reason?: string }> {
    await this.ensureDepositFloat();

    const floatKey = "broker:deposit_float_minor";
    const riskKey = this.getRiskKey(params.symbol, params.expiryBucket, params.direction);
    const payoutPct = params.payoutPercentage || this.PAYOUT_PERCENTAGE;
    const ttlSeconds = 600;

    const result = (await this.redis.eval(
      this.checkScript,
      2,
      floatKey,
      riskKey,
      params.stakeMinor,
      payoutPct,
      ttlSeconds
    )) as [number, string, number?];

    const statusCode = result[0];
    if (statusCode === 1) {
      return { approved: true };
    }

    return {
      approved: false,
      reason: result[1] || "RISK_CAP_EXCEEDED"
    };
  }

  async releaseRisk(params: ReserveRiskParams): Promise<void> {
    const riskKey = this.getRiskKey(params.symbol, params.expiryBucket, params.direction);
    const payoutPct = params.payoutPercentage || this.PAYOUT_PERCENTAGE;
    const riskAmount = Math.floor((params.stakeMinor * payoutPct) / 100);

    await this.redis.eval(this.releaseScript, 1, riskKey, riskAmount);
  }
}
